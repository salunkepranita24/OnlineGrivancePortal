import React , { Component } from 'react';
import ReactDOM from 'react-dom';
import  {BrowserRouter as Router, Switch, Route,Link} from  "react-router-dom";
import { createBrowserHistory as history} from 'history';
//import React from 'react';
//import "react-toastify/dist/ReactTostify.css";
 import './App.css';
 import Navbar from "./components/navbar/Navbar"
 import RegistrationFormComponent from './components/RegistrationFormComponent';
 import LoginComponent from './components/LoginComponent';
 import adminLogin from './components/adminLogin';
 import feedbackAll from './components/feedbackAll';
import ComplaintComponent from "./components/ComplaintComponent";
import ChangePasswordComponent from "./components/ChangePasswordComponent";
//import AdminComponent from "./components/AdminComponent"
import StudentDashboardComponent from "./components/StudentDashboardComponent";
import StaffDashboardComponent from "./components/StaffDashboardComponent";
import EditComplaintComponent from "./components/EditComplaintComponent";
import CordinatorDashboardComponent from "./components/CordinatorDashboardComponent";
import Status from "./components/Status";
import Management from "./components/Management";
import Student from "./components/Student";
import Staff from "./components/Staff";
import Coordinator from "./components/Coordinator";
import Feedback from "./components/Feedback";
import StaffRegistration from "./components/StaffRegistration";
import StudentDeletion from "./components/StudentDeletion";
import StaffDeletion from "./components/StaffDeletion";
import CordinatorDeletion from "./components/CordinatorDeletion";
import Admin from "./components/Admin";
import UpdateStudent from "./components/UpdateStudent";
import image from './images/iacsd3.jpg';



class App extends Component { 
  render(){
    
    return (
    <div >
     
    <BasicRouting></BasicRouting>
    </div>
    );
  }
}

export default App;






function BasicRouting(){
return(
  
    <div>
      <Router history={history}>
     
      <Navbar/>
    <Switch>
         <Route  path="/" exact component={Home} />
        <Route path="/login" exact component={LoginComponent} />
        <Route path="/user" component={RegistrationFormComponent} />
        <Route path="/complaint" component={ComplaintComponent} />
        <Route path="/changePassword" component={ChangePasswordComponent} />
        <Route path="/admin" exact component={adminLogin} />
        <Route path="/studentDash" component={StudentDashboardComponent} />
        <Route path="/staffDash" component={StaffDashboardComponent} />
        <Route path="/edit-complaint" component={EditComplaintComponent} />
        <Route path="/cordinatorDash" component={CordinatorDashboardComponent} />
        <Route path="/studentDeletion" component={StudentDeletion} />
        <Route path="/management" component={Management}/>
        <Route path="/student" component={Student}/>
        <Route path="/cordinator" component={Coordinator}/>
        <Route path="/staff" component={Staff}/>
        <Route path="/status" component={Status}/>
        <Route path="/staffDeletion" component={StaffDeletion} />
        <Route path="/staffRegistration" component={StaffRegistration} />
        <Route path="/cordinatorDeletion" component={CordinatorDeletion} />
        <Route path="/about"> <About/></Route>
     
        <Route path="/contact"><Contact/> </Route>
        <Route path="/admin1" component={Admin} />
        <Route path="/feedback" component={Feedback} />
        <Route path="/feedbacklist" component={feedbackAll} />
        <Route path="/updateStudent" component={UpdateStudent} />
       
    </Switch>
    
    </Router>
    </div>
   
 
         
  );
} 

const style = {
  color: 'red',
  margin: '10px'
}



class  Home extends Component{
  render(){
    return(
      <div>
          <div >
            <center>
            <div >
            {<img src={image} alt="alt logo"
            width="1450px"
     height="575px"
      ></img>}
           
            </div> 
            </center>
          </div>  
      </div>
    );
  }
}


// function Home(){
//   return(
//     <div class="container"> 
// <div class="jumbotron jumbotron-fluid">
// <Link to="/"> Home </Link>|<Link to="/about"> About </Link> |<Link to="/contact"> Contact us </Link> |<Link to="/login"> Login </Link>
//   <h1>Online Grievance System</h1>
 
//    {<img src={process.env.PUBLIC_URL+"/images/iacsd3.jpg"}
//      alt="Mypic"
    
//      width="1500px"
//      height="550px"
//      ></img>}
     
//      </div>
//    </div>
//   );
// }



//  function About(){

//    return(
//      <div  style={{background:'red',padding:20}}>
//        <h2>About</h2>
      
//       <hr/>
//       <p>Institute for Advanced Computing and Software Development (IACSD)</p>
//        <p>It is the outcome of visionary mission of Dr. D. Y. Patil, Founder President of Dr. D. Y. Patil Pratishthan.</p>
//        <p>The core strength of the institute lies in the dynamic management team, excellent infrastructure, experienced and qualified faculties
//           who have been trained to deliver the latest and most advanced technological knowledge to the students.</p>
//         <p>Institute for Advanced Computing & Software Development,
//           Dr. D.Y. Patil Educational Complex,
//           Sector 29, Behind Akurdi Railway Station,
//          Nigdi Pradhikaran, Akurdi
//          Pune - 411044.</p>
//      </div>

//    );
//  }
function About(){
 
  return (
      <div>
          <div >
              <div className="container">
                  <div className="row">
                      <div className="card col-md-6 offset-md-3 offset-md-3">
                          <h3 className="text-center" style={style}>About</h3>
                          <div className="card-body">
                          <hr/>
      <p>Institute for Advanced Computing and Software Development (IACSD)</p>
       <p>It is the outcome of visionary mission of Dr. D. Y. Patil, Founder President of Dr. D. Y. Patil Pratishthan.</p>
       <p>The core strength of the institute lies in the dynamic management team, excellent infrastructure, experienced and qualified faculties
          who have been trained to deliver the latest and most advanced technological knowledge to the students.</p>
        <p>Institute for Advanced Computing & Software Development,
          Dr. D.Y. Patil Educational Complex,
          Sector 29, Behind Akurdi Railway Station,
         Nigdi Pradhikaran, Akurdi
         Pune - 411044.</p>
      
                           
                           <p className="text-center"></p>
                              <p className="text-center"></p>
                           <p className="text-center"></p>
                            <p className="text-center"></p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  )
}

function Contact(){
 
  return (
      <div>
          <div >
              <div className="container">
                  <div className="row">
                      <div className="card col-md-6 offset-md-3 offset-md-3">
                          <h3 className="text-center" style={style}>Contact Us</h3>
                          <div className="card-body">
                          <hr/>
                         
      <p>Institute for Advanced Computing and Software Development (IACSD)</p>
      <p>Phone:+91 9607690988/20-27659509/27652794</p>
      <p>E-mail: ittrg@iacsd.com</p>
     
      
                           
                           <p className="text-center"></p>
                              <p className="text-center"></p>
                           <p className="text-center"></p>
                            <p className="text-center"></p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  )
}
const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);

