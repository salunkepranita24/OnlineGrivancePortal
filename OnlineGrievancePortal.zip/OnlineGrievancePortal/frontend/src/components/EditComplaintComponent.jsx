import React, { Component } from 'react'
import UserServices from '../Services/UserServices.js'
import { Link } from 'react-router-dom';

class EditComplaintComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
            id: '',
            cptType: '',
            cptDesc: ''
           
        }
        this.saveComplaint = this.saveComplaint.bind(this);
        this.loadComplaint = this.loadComplaint.bind(this);
    }

    componentDidMount() {
        this.loadComplaint();
    }

    loadComplaint() {
        UserServices.fetchComplaintById(window.localStorage.getItem("complaintId"))
            .then((res) => {
                let complaint = res.data.result;
                this.setState({
                id: complaint.id,
                cptType: complaint.cptType,
                cptDesc: complaint.cptDesc
               
                })
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    saveComplaint = (e) => {
        e.preventDefault();
        let complaint = {cptType: this.state.cptType, cptDesc: this.state.cptDesc};
        UserServices.editComplaint(complaint)
            .then(res => {
                this.setState({message : 'Complaint added successfully.'});
                this.props.history.push('/studentDash');
            });
    }

    render() {
        return (
            <div>
                <h2 className="text-center">Edit Complaint</h2>
                <form>

                    <div className="form-group">
                        <label>Complaint Type:</label>
                        <input type="text" placeholder="cptType" name="cptType" className="form-control" readonly="true" defaultValue={this.state.cptType}/>
                    </div>

                    <div className="form-group">
                        <label>Write Complaint:</label>
                        <input placeholder="Write Complaint" name="cptDesc" className="form-control" value={this.state.cptDesc} onChange={this.onChange}/>
                    </div>

                   

                    <button className="btn btn-success" onClick={this.saveComplaint}>Save</button>
                </form>
            </div>
        );
    }
}

export default EditComplaintComponent;