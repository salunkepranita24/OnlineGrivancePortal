import React, { Component } from 'react'
import UserServices from '../Services/UserServices.js'
import { Link } from 'react-router-dom';

class CordinatorDashboardComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            complaints: [],
            message: null
        }
       // this.deleteComplaint = this.deleteComplaint.bind(this);
       // this.editComplaint = this.editComplaint.bind(this);
       // this.addComplaint = this.addComplaint.bind(this);
        this.reloadComplaintList = this.reloadComplaintList.bind(this);
    }

    componentDidMount() {
        this.reloadComplaintList();
    }

    reloadComplaintList() {
        UserServices.fetchComplaints()
            .then((res) => {
                this.setState({complaints: res.data.result})
                console.log(this.state.complaints);
            });
            // UserService.getUsers().then(resp => {
            //     this.setState({ users: resp.data });
            //     console.log(this.state.users);
            // })
    }

    // deleteComplaint(complaintId) {
    //     UserServices.deleteComplaint(complaintId)
    //        .then(res => {
    //            this.setState({message : 'Complaint deleted successfully.'});
    //            this.setState({complaints: this.state.complaints.filter(complaint => complaint.id !== complaintId)});
    //        })

    // }

    // editComplaint(id) {
    //     window.localStorage.setItem("complaintId", id);
    //     this.props.history.push('/edit-complaint');
    // }

    // addComplaint() {
    //     window.localStorage.removeItem("complaintId");
    //     this.props.history.push('/add-complaint');
    // }

    render() {
        return (
            <div>
                <h2 className="text-center">Coordinator DashBoard</h2>
                <h1>ALl Complaints:</h1>
                <button className="btn btn-danger" style={{width:'100px'}} onClick={() => this.addUser()}> Password</button>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Date</th>
                            <th>Complaint Type</th>
                            <th>Description</th>
                            <th>Status</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.complaints.map(
                        complaint =>
                                    <tr key={complaint.id}>
                                        <td>{complaint.date}</td>
                                        <td>{complaint.complaintType}</td>
                                        <td>{complaint.description}</td>
                                        <td>{complaint.status}</td>
                                      
                                        <td>
                                            <button className="btn btn-success" onClick={() => this.deleteComplaint(complaint.id)}> Delete</button>
                                            <button className="btn btn-success" onClick={() => this.editComplaint(complaint.id)} style={{marginLeft: '20px'}}> Edit</button>
                                        </td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }

}

export default CordinatorDashboardComponent;