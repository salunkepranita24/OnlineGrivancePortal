import React, { Component } from 'react'
import UserServices from '../Services/UserServices.js'
import { Link } from 'react-router-dom';

class feedbackAll extends Component {

    constructor(props) {
        super(props)
        this.state = {
            feedbacks: [],
            message: null
        }
       
    }

  
    componentDidMount(){
        UserServices.getAllFeedback().then((res)=>{
            this.setState({feedbacks: res.data})
           
        });
    }

   
   
    render() {
        return (
            <div  className="col-md-10" style={{marginLeft: '20px'}}>
                <h2 className="text-center"> All Feedback</h2>
               {/* <Link to="/complaint"><button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.addComplaint()}> Register Complaint</button></Link>
              <Link to="/feedback"><button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.addComplaint()} style={{marginLeft: '20px'}}> Feedback</button></Link>
                {/* <Link to="/changePassword"><button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.addComplaint()} style={{marginLeft: '20px'}}> Password</button></Link>*/}
                 <Link to="/studentDash"><button className="btn btn-danger" style={{width:'200px'}}  style={{marginLeft: '560px'}}> Log Out</button></Link>  
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Feedback</th>
                            <th>Date</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.feedbacks.map(
                        feedback =>
                        <tr key={feedback.id}>
                        <td>{feedback.id}</td>
                        <td>{feedback.name}</td>
                        <td>{feedback.email}</td>
                        <td>{feedback.feedback}</td>
                        <td>{feedback.date}</td>
                                       
                         </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }

}

export default feedbackAll;