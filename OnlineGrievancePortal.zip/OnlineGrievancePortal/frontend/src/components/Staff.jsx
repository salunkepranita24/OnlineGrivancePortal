import React from 'react';
import { Card, Container, Jumbotron } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Button, CardBody } from 'reactstrap';

const Staff = (props) => {
  return (
    <div>
      <Jumbotron className="text-center">
        <Card>
           <CardBody>
            <h1 className="text-center my-1">ADMIN</h1>
            <p>Welcome to Adminstrator</p>
        </CardBody>
        </Card>
        <hr/>
       <Container >
         
         <h2>Staff Registration</h2>
         <Link to="/staffRegistration"><Button color="primary" size="lg" >ADD STAFF</Button>{' '}</Link>
       <hr/>
       <Link to="/user"><Button color="primary" size="lg" >UPDATE STAFF</Button>{' '}</Link>
       <hr/>
       <Link to="/staffDeletion"><Button color="primary" size="lg" >REMOVE STAFF</Button>{' '}</Link>
      
       
       
      
    </Container>
    </Jumbotron>
    </div>
  );
}

export default Staff;