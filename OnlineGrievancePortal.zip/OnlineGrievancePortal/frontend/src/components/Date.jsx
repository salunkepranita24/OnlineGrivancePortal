import React from 'react'

var date=()=>
{
    var showDate=new Date();
    var displaytodaysdate=showDate.getDate()+'/'+(showDate.getMonth()+1)+'/'+showDate.getFullYear();
    var dt=showDate.toDateString();
    return(
        <div>
            <input type='text' value={displaytodaysdate} readOnly="true"/>
        </div>
         
    )
}
export default date;