import React, { Component } from 'react'
import UserServices from '../Services/UserServices.js'
import { Link } from 'react-router-dom';
import Date from '../components/Date';
class ComplaintComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {

            name: '',
            email: '',
            feedback:'',
            date: '',

            complaint: { id:2}
                
   
           
        }
        this.saveFeedback = this.saveFeedback.bind(this);
        
    }

    saveFeedback = (e) => {
        e.preventDefault();
        let feedback = {
            name: this.state.name, email: this.state.email,
             feedback: this.state.feedback,date: this.state.date,complaint: this.state.complaint
        };
        console.log(JSON.stringify(feedback))
        UserServices.addFeedback(feedback)
            .then(res => {
                this.setState({ message: 'complaint added successfully.' });
                this.props.history.push('/feedbacklist');
            });
    }
   
   

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });
 
        

    render() {
        return (
            <div>
                <div>
                    <div className="container">
                        <div className="row">
                            <div className="card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center"> Feedback Form</h3>
                                <div className="card-body">
                                    <form>


                                        <div className="form-group">
                                            <label>Name</label>
                                            <input type="text" placeholder="name" name="name" className="form-control" value={this.state.name} onChange={this.onChange} />
                                        </div>

                                        <div className="form-group">
                                            <label>Email:</label>
                                            <input type="text" placeholder="email" name="email" className="form-control" value={this.state.email} onChange={this.onChange} />
                                        </div>
                                        <div className="form-group">
                                            <label>Feedback:</label>
                                            <input type="text" placeholder="feedback" name="feedback" className="form-control" value={this.state.feedback} onChange={this.onChange} />
                                        </div>

                                        <div className="form-group">
                                           
                                        <label>Date</label>
                                         <input type="date" placeholder="Date" name="date" className="form-control" value={this.state.date} onChange={this.onChange} />
                                            
                                        </div>

                                          
{/*                                            
                                         <Date/>
                                         </div> */}

                                        <button className="btn btn-success" onClick={this.saveFeedback}>Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}


export default ComplaintComponent;