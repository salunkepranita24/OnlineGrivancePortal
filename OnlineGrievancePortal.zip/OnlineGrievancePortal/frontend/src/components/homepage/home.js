import React , { Component } from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router , Switch,Route,Link} from "react-router-dom";
import './home.css'
import image1 from '../../images/kid1.jpg'

class  Home extends Component{
    render(){
      return(
       /* <div>
       </div> <div class="slideshow-container">

        
        <div className="mySlides fade">
          <img src={image1}>
        </div>
      
        <div class="mySlides fade">
          <div class="numbertext">2 / 3</div>
          <img src="img2.jpg" style="width:100%">
          <div class="text">Caption Two</div>
        </div>
      
        <div>
          <div class="numbertext">3 / 3</div>
          <img src="img3.jpg" style="width:100%">
          <div class="text">Caption Three</div>
        </div>
      
       <div>
        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>
      </div>
     
      
     
      <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
      </div>

      </div>*/
      <div></div>
      );
    }
  }

export default Home;