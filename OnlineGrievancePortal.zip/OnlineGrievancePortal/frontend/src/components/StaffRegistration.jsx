import React, { Component } from 'react'
import UserServices from "../Services/UserServices";

class StaffRegistration extends Component{

    constructor(props){
        super(props);
        this.state ={
            name: '',
            email: '',
           password: '',
         roles:''
          
           
            
        }
        this.saveUser = this.saveUser.bind(this);
    }
    saveUser = (e) => {
        e.preventDefault();
        let user = {name: this.state.name, email: this.state.email,password: this.state.password
             };
             console.log(user);
             UserServices.addUser(user)
            .then(res => {
                this.setState({message : 'User added successfully.'});
                this.props.history.push('/staffDash');
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });
    render() {
        return( 
            <div className="register-user">
                <h2 className="text-center">Register Staff</h2>
                <form>
                <div className="form-group">
                    <label> Name</label>
                    <input placeholder=" Name" name="name" className="form-control" value={this.state.name} onChange={this.onChange}/>
                </div>

              <div className="form-group">
                    <label>Email</label>
                    <input type="Email" placeholder="Email" name="email" className="form-control" value={this.state.email} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Password</label>
                    <input type="Password" placeholder="Password" name="password" className="form-control" value={this.state.password} onChange={this.onChange}/>
                </div>
                <div className="form-group">
                    <label>Roles</label>
                    <input type="text" placeholder="roles" name="roles" className="form-control" value={this.state.roles} onChange={this.onChange}/>
                </div>
         

               
                <button className="btn btn-success" onClick={this.saveUser}  >Register</button>
            </form>
    </div>
        );
    }
}

export default StaffRegistration;
