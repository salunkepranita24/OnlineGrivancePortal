import React from 'react';
import { Card, Container, Jumbotron } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Button, CardBody } from 'reactstrap';

const Management = (props) => {
  return (
    <div>
      <Jumbotron className="text-center">
        <Card>
           <CardBody>
            <h1 className="text-center my-1">ADMIN</h1>
            <p>Welcome to Adminstrator</p>
        </CardBody>
        </Card>
        <hr/>
       <Container >
         
         <h2>Management Registration</h2>
         <Link to="/user"><Button color="primary" size="lg" >ADD MANAGEMENT</Button>{' '}</Link>
       <hr/>
       <Link to="/user"><Button color="primary" size="lg" >UPDATE MANAGEMENT</Button>{' '}</Link>
       <hr/>
       <Link to="/user"><Button color="primary" size="lg" >REMOVE MANAGEMENT</Button>{' '}</Link>
      
       
       
      
    </Container>
    </Jumbotron>
    </div>
  );
}

export default Management;