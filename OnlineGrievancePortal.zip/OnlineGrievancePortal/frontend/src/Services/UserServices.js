import axios from 'axios';

const USER_BASE_API_URL = 'http://localhost:8080/'
class UserServices {

    addUser(user){
        return axios.post(USER_BASE_API_URL+"/user/register",user);
      }
  
      login(email, password) {
          return axios
            .post(USER_BASE_API_URL + "/user/login", {
              email,
              password
            })
            .then(response => {
              if (response.data.accessToken) {
                localStorage.setItem("user", JSON.stringify(response.data));
              }
      
              return response.data;
            });
        }
  
        getUser(){
          return axios.get(USER_BASE_API_URL+"/user/all");
      }
    fetchUsers(){
        return axios.get(USER_BASE_API_URL);
    }

    fetchUserById(userId)
    {
        return axios.get(USER_BASE_API_URL+"/user"+userId);
    }

    deleteUser(userId)
    {
        return axios.delete(USER_BASE_API_URL+"/user"+userId);
    }

    
    editUser(user){
        return axios.put(USER_BASE_API_URL+"/user"+user.Id,user);
    }

    addFeedback(feedback){
      return axios.post(USER_BASE_API_URL+"/feedback/create",feedback);
    }
     getAllFeedback(){
       return axios.get(USER_BASE_API_URL+'/feedback/all');
     }

      getUserById(id) {
        return axios.get(USER_BASE_API_URL,+"/details" ,id);
    }


    //   getUsers(){
    //     return axios.get(USER_BASE_API_URL+"/all");
    // }

   

    // updateUser(user){
    //     return axios.put(USER_BASE_API_URL+"/update/"+user.id,user);
    // }

    // deleteUser(id){
    //     return axios.delete(USER_BASE_API_URL+"/delete/"+id);
    // }

    addComplaint(complaint){
      return axios.post(USER_BASE_API_URL+"/complaint/register",complaint);
    }


    
    // fetchUsers() {
    //     return axios.get(USER_BASE_API_URL);
    // }
     fetchComplaints() {
         return axios.get(USER_BASE_API_URL);
     }
     fetchFeedacks() {
      return axios.get(USER_BASE_API_URL);
  }

    // fetchUserById(userId) {
    //     return axios.get(USER_BASE_API_URL + '/' + userId);
    // }
     fetchComplaintById(complaintId) {
        return axios.get(USER_BASE_API_URL + '/complaint/register' + complaintId);
     }
     fetchFeedbackById(feedbackId) {
         return axios.get(USER_BASE_API_URL + '/feedback/create' + feedbackId);
     }
fetchAllComplaint(complaints)
{
  return axios.get(USER_BASE_API_URL +'/complaint/all',complaints);
}
fetchAllFeedback(feedbacks)
{
  return axios.get(USER_BASE_API_URL +'/feedback/all',feedbacks);
}
   
     deleteComplaint(complaintId) {
         return axios.delete(USER_BASE_API_URL + '/complaint/' + complaintId);
     }

    
     editUser(user) {
         return axios.put(USER_BASE_API_URL + '/' + user.id, user);
     }
     getAllComplaints(){
       return axios.get(USER_BASE_API_URL+'/complaint/all')
     }
     editComplaint(complaintId)
     {
       return axios.put(USER_BASE_API_URL+'/complaint/'+complaintId)
     }

/*
    loginUser (user) {
        return axios.get(USER_BASE_API_URL+"/login", user);
    }*/
}
export default new UserServices();
