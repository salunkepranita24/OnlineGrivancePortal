package com.app.controller;


import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.ComplaintRepository;
import com.app.model.UserModel;
import com.app.pojos.*;
import com.app.service.*;


@RestController
@RequestMapping("/complaint")
@CrossOrigin
public class ComplaintController {

	@Autowired
	private IComplaintService complaintService;
	
	@Autowired
	private ComplaintRepository complaintRepo; 
	
	@GetMapping("/all")
	public Set<Complaint> getAllComplaints() {
		System.out.println("in get all complaints");
		return complaintService.getAllComplaints();

	}
	
//	@GetMapping("/{complaintId}")
//	
//	public Complaint getComplaint(@PathVariable String complaintId)
//	{
//		return this.complaintService.getComplaint(Long.parseLong(complaintId));
//	}
//	

	@PostMapping("/register")
	public ResponseEntity<?> registerComplaint(@RequestBody Complaint complaint) {
		System.out.println("In post mapping of complaint");
		Complaint retcomplaint = complaintService.registerComplaint(complaint);
		return new ResponseEntity<Complaint>(retcomplaint, HttpStatus.OK);
	}
	
//	@GetMapping("/combyuserid/{id}")
//	public List<Complaint> combyuserid(@PathVariable int id) {
//		System.out.println("in method of "+getClass().getName());
//		System.out.println("ngo ID "+id);
//		List<Complaint> request=complaintService.listCompByUserId(id);
//		return request;
	//}
	@DeleteMapping("/{cid}")
	   public ResponseEntity<?>deleteComplaint(@PathVariable int cid)
		{
		System.out.println("in delete complaint controller");
			try {
			return new ResponseEntity<>(complaintService.deleteComplaint(cid),HttpStatus.OK);
			}
			catch(RuntimeException e){
				e.printStackTrace();
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
				
			}
		}


	@PutMapping("/{id}")
	   public ResponseEntity<?> updateComplaint(@PathVariable int id, @RequestBody Complaint complaint) {
	      
		   complaintService.updateComplaint(id, complaint);
	      return new ResponseEntity<>("Complaint is updated successsfully", HttpStatus.OK);
	   }
	 /*  @RequestMapping("/checkStatus")
		public String checkStatus(HttpSession session) {
			Login login = (Login) session.getAttribute("login");
			Integer prn = login.getPrn();
			List<Complaint> list = complaintService.myComplaints(prn);
			for(Complaint c : list)
			{
				System.out.println(c);
			}
			session.setAttribute("myCom_list", list);
			return "checkStatus";
		}*/
	
	
	
	
}
