package com.app.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ComplaintRepository;
import com.app.dao.FeedbackRepository;
import com.app.pojos.Complaint;
import com.app.pojos.Feedback;

@Service
@Transactional
public class FeedbackServiceImpl implements IFeedbackService {
	
	@Autowired
	private  FeedbackRepository feedbackDao; 
	
	@Override
	public Feedback createFeedback(Feedback f) {
	
		return feedbackDao.save(f);
	}

	@Override
	public Set<Feedback> getAllComplaints() {
		// TODO Auto-generated method stub
		return new HashSet(feedbackDao.findAll());
	}

	
	
}
