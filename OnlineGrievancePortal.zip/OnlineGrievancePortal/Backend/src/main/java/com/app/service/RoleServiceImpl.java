package com.app.service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.RoleRepository;
import com.app.dao.UserRepository;
import com.app.pojos.Role;
import com.app.pojos.User;
 

@Service
@Transactional
public class RoleServiceImpl implements IRoleService {
@Autowired
	private RoleRepository roleRepository;
@Autowired
    private UserRepository userRepository;


    public RoleServiceImpl() {
    	System.out.println("in roleService ctr");
    }

    /** Create a new role  */
 
    public Role createRole(Role role)  {

        Role newRole = new Role();
        newRole.setName(role.getName());
       // newRole.setDescription(role.getDescription());
        Set<Role> roleSet = new HashSet<>();
        roleSet.add(newRole);
        System.out.println("user"+role.getUsers());
        Set <User>users=role.getUsers();
        for(User u :users)
        {
        	Optional<User> user=userRepository.findByEmail( u.getEmail());
            if(user.get() == null)
            {
                User newUser = user.get();
                newUser.setRoles(roleSet);
                User savedUser = userRepository.save(newUser);
              //the method get(int) is undefined for the type Set<User>
            }
            else  
            	return null;
        }
        return newRole;
    }


    /** Delete a specified role given the id */
    public Role deleteRole(int id) {
        if(roleRepository.findById(id).isPresent()){
            if(roleRepository.getOne(id).getUsers().size() == 0) {
                roleRepository.deleteById(id);
                if (roleRepository.findById(id).isPresent()) {
                    return null;
                } return null;
            } return null;
        } else return null;
    }


    /** Update a Role */
    public Role updateRole(int id, Role role) {
	
        if(roleRepository.findById(id).isPresent()){
            Role newRole = roleRepository.findById(id).get();
            newRole.setName(role.getName());
            System.out.println("name"+newRole.getName());
          //  newRole.setDescription(role.getDescription());
            Role savedRole = roleRepository.save(newRole);
            //if(roleRepository.findById(savedRole.getId()).isPresent())
                return newRole;
       // else return null;

        } else return null;
    }
}

