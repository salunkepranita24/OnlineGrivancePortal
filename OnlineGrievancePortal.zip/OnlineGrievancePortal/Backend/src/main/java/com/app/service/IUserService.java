package com.app.service;





import java.util.Set;

import com.app.model.UserModel;
import com.app.pojos.User;

public interface IUserService {

	User createUser(User user);

	UserModel getUser(int id);

	Set<UserModel> getUsers();

	User updateUser(int id, User user);

	

//	User addNewUser(User user);
//
//	User updateUser(int cid, User user);
//
	User deleteUser(int cid);

	//User authenticateUser(User user);

	User authenticateUser(String email, String password);

	User getByEmail(String email);

	
	

}
