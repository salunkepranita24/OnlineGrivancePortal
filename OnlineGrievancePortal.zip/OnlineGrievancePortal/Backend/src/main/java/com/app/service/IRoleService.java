package com.app.service;

import com.app.pojos.Role;

public interface IRoleService {
	Role createRole(Role role);

	Role deleteRole(int id);

	Role updateRole(int id, Role role);

}
