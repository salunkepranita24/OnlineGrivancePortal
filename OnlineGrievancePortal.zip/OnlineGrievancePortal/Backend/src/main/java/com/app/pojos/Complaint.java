package com.app.pojos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="complaint")
public class Complaint {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String cptDesc;
	private String cptType;
	//private String status;
	@DateTimeFormat(pattern = "dd-mm-yyyy")
	private LocalDate date;
	//private int count;
	
	
	
	@ManyToOne
	@JoinColumn(name="e_id",nullable = false)
	private User complaintOwner;

	
	@JsonIgnore
	@OneToMany(mappedBy = "complaint",cascade=CascadeType.ALL,orphanRemoval = true,fetch=FetchType.EAGER)
	private List<Feedback> feedbacks=new ArrayList<>();

	public Complaint() {
		super();
	}

	public Complaint(String cptDesc, String cptType/*, String status*/, LocalDate date,/*, int count*/ User complaintOwner)
			{
		super();
		this.cptDesc = cptDesc;
		this.cptType = cptType;
		//this.status = status;
		this.date = date;
		//this.count = count;
		//this.complaintOwner = complaintOwner;
		
	}

	public String getCptDesc() {
		return cptDesc;
	}

	public void setCptDesc(String cptDesc) {
		this.cptDesc = cptDesc;
	}

	public String getCptType() {
		return cptType;
	}

	public void setCptType(String cptType) {
		this.cptType = cptType;
	}

//	public String getStatus() {
//		return status;
//	}
//
//	public void setStatus(String status) {
//		this.status = status;
//	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

//	public int getCount() {
//		return count;
//	}
//
//	public void setCount(int count) {
//		this.count = count;
//	}



	public List<Feedback> getFeedbacks() {
		return feedbacks;
	}

	public void setFeedbacks(List<Feedback> feedbacks) {
		this.feedbacks = feedbacks;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public User getComplaintOwner() {
		return complaintOwner;
	}

	public void setComplaintOwner(User complaintOwner) {
		this.complaintOwner = complaintOwner;
	}

	@Override
	public String toString() {
		return "Complaint [cptDesc=" + cptDesc + ", cptType=" + cptType + ", date=" + date
				   + ", complaintOwner=" + complaintOwner + "]";
	}

	
	

}
