package com.app.exception;

@SuppressWarnings("serial")
public class UserException extends RuntimeException{
	public UserException(String msg) {
		super(msg);
	}

}
